import React, { useState } from 'react';
import { Book, CategoryScience, IsnadNode, ReaderTheme, ReadingSection, WordAnalysis } from '../types/library';

interface HomeViewProps {
  books: Book[];
  categories: CategoryScience[];
  readingSection: ReadingSection;
  onSelectBook: (book: Book) => void;
  onOpenReader: (book?: Book) => void;
  onOpenDownload: (book: Book) => void;
  onOpenNarrator: (narrator: IsnadNode) => void;
  onOpenWordAnalysis: (word: WordAnalysis) => void;
  onNavigate: (path: string) => void;
  onSearchQuery: (query: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  books,
  categories,
  readingSection,
  onSelectBook,
  onOpenReader,
  onOpenDownload,
  onOpenNarrator,
  onOpenWordAnalysis,
  onNavigate,
  onSearchQuery
}) => {
  const [heroSearchInput, setHeroSearchInput] = useState('');
  const [activeFeaturedTab, setActiveFeaturedTab] = useState('All Works');
  
  // Reader interactive state
  const [readerTheme, setReaderTheme] = useState<ReaderTheme>('parchment');
  const [readerFontSize, setReaderFontSize] = useState<number>(18);
  const [showParallelTranslation, setShowParallelTranslation] = useState<boolean>(true);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [activeFootnoteOpen, setActiveFootnoteOpen] = useState<boolean>(true);
  const [shareToast, setShareToast] = useState<boolean>(false);

  // Newsletter state
  const [dispatchEmail, setDispatchEmail] = useState('');
  const [dispatchSubscribed, setDispatchSubscribed] = useState(false);

  const filterTabs = ['All Works', 'Most Read', 'Recently Digitized', 'Rare Manuscripts', 'Bilingual (Ar/En)'];

  const getFilteredBooks = () => {
    switch (activeFeaturedTab) {
      case 'Most Read':
        return books.filter(b => b.rating >= 4.9);
      case 'Recently Digitized':
        return books.filter(b => b.pages > 500);
      case 'Rare Manuscripts':
        return books.filter(b => b.formats.includes('Critical PDF'));
      case 'Bilingual (Ar/En)':
        return books.filter(b => b.badge?.includes('English') || b.badge?.includes('Bilingual') || b.formats.includes('English Translation'));
      default:
        return books.slice(0, 4);
    }
  };

  const handleHeroSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearchInput.trim()) {
      onSearchQuery(heroSearchInput);
      onNavigate('browse-library');
    }
  };

  const handleTagClick = (tag: string) => {
    onSearchQuery(tag);
    onNavigate('browse-library');
  };

  const handleShareHadith = () => {
    navigator.clipboard?.writeText(
      `Ṣaḥīḥ al-Bukhārī, Hadīth #1: “The reward of deeds depends upon the intentions...” [Al-Maktabah Digital Archives]`
    );
    setShareToast(true);
    setTimeout(() => setShareToast(false), 3000);
  };

  const handleDispatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dispatchEmail) return;
    setDispatchSubscribed(true);
    setTimeout(() => {
      setDispatchEmail('');
      setDispatchSubscribed(false);
    }, 4500);
  };

  return (
    <div className="w-full">
      {/* Top Daily Ayah / Hadith Calligraphic Banner */}
      <div className="relative w-full overflow-hidden bg-surface-container-high/70 backdrop-blur-md rounded-xl p-space-md shadow-sm mb-space-xl border border-surface-container">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-space-md">
          <div className="flex items-center gap-space-md">
            <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-tertiary-container/20 text-tertiary shrink-0">
              <span className="material-symbols-outlined text-base">auto_stories</span>
            </span>
            <div className="flex flex-col md:flex-row md:items-baseline gap-1 md:gap-space-md">
              <span className="font-arabic font-title-lg text-title-lg text-tertiary font-bold tracking-wide text-lg">
                « رَبِّ زِدْنِي عِلْمًا »
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant font-medium">
                “My Lord, increase me in knowledge.”{' '}
                <span className="text-tertiary text-label-sm font-label-sm uppercase font-semibold tracking-wider ml-1">
                  (Surah Ta-Ha 20:114)
                </span>
              </span>
            </div>
          </div>
          <div className="flex items-center gap-space-md text-on-surface-variant font-label-md text-label-md">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container-lowest shadow-sm text-primary font-medium border border-surface-container">
              <span className="material-symbols-outlined text-sm text-tertiary-container">verified</span>
              Verified Canonical Matn
            </span>
            <span className="hidden lg:inline-flex text-on-surface-variant">Shawwal 1445 AH Edition</span>
          </div>
        </div>
        {/* Ambient subtle geometric watermark inside strip */}
        <div className="absolute -right-6 -bottom-6 w-32 h-32 opacity-5 pointer-events-none text-primary">
          <svg fill="currentColor" viewBox="0 0 100 100">
            <polygon points="50,0 62,38 100,38 69,62 81,100 50,75 19,100 31,62 0,38 38,38"></polygon>
          </svg>
        </div>
      </div>

      {/* Hero Section (Desktop Split Layout) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-space-xl items-center pb-space-xl">
        {/* Left Hero Column */}
        <div className="lg:col-span-7 flex flex-col gap-space-lg">
          <div className="inline-flex items-center gap-2 self-start px-3.5 py-1.5 rounded-full bg-surface-container-low shadow-sm border border-surface-container">
            <span className="font-arabic font-title-md text-title-md text-tertiary font-bold">
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-tertiary-container"></span>
            <span className="font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant font-semibold">
              Classical Heritage Index
            </span>
          </div>

          <div className="space-y-space-sm">
            <h1 className="font-headline-lg text-headline-lg text-primary tracking-tight font-bold">
              Authentic Islamic Books &amp; Scholarly Knowledge
              <span className="block font-display italic text-tertiary font-normal mt-1">
                Open, Free &amp; Preserved For All.
              </span>
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl leading-relaxed">
              Preserving and digitizing timeless classical treatises, contemporary research, Qur’anic exegesis, and authenticated hadith collections in pristine typography for scholars, students, and seekers worldwide.
            </p>
          </div>

          {/* Interactive Search Pill */}
          <div className="relative w-full max-w-2xl bg-surface-container-lowest rounded-xl p-2 shadow-md border border-surface-container">
            <form onSubmit={handleHeroSearchSubmit} className="flex items-center gap-space-sm px-3 py-1">
              <span className="material-symbols-outlined text-tertiary-container text-2xl">menu_book</span>
              <input
                className="w-full bg-transparent border-0 focus:outline-none font-body-md text-body-md text-on-surface placeholder:text-outline"
                placeholder="Search treatises, isnād chains, authors, or subjects (e.g. Bukhari, Ghazali)..."
                type="text"
                value={heroSearchInput}
                onChange={(e) => setHeroSearchInput(e.target.value)}
              />
              <button
                type="submit"
                className="shrink-0 px-4 py-2 bg-primary-container text-on-primary rounded-lg font-title-md text-title-md hover:bg-primary transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <span>Explore</span>
                <span className="material-symbols-outlined text-base">arrow_forward</span>
              </button>
            </form>
            <div className="mt-2 pt-2 px-3 flex flex-wrap items-center gap-1.5 bg-surface-container-low/50 rounded-lg py-1.5 border-t border-surface-container">
              <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">Direct Access:</span>
              {['Sahih al-Bukhari', 'Imam al-Ghazali', 'Tafsir Ibn Kathir', 'Seerah', 'Tazkiyah'].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handleTagClick(tag)}
                  className="px-2 py-0.5 rounded-md bg-surface-container-lowest hover:bg-primary-container hover:text-on-primary text-on-surface-variant font-label-sm text-label-sm transition-colors shadow-xs border border-surface-container cursor-pointer"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-space-md pt-space-xs">
            <button
              onClick={() => onNavigate('browse-library')}
              className="px-6 py-3 rounded-lg bg-primary-container text-on-primary font-title-md text-title-md hover:bg-primary shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-lg">local_library</span>
              <span>Explore 14,000+ Titles</span>
            </button>
            <button
              onClick={() => onOpenReader()}
              className="px-6 py-3 rounded-lg bg-surface-container-high text-on-surface font-title-md text-title-md hover:bg-surface-container-highest transition-colors flex items-center gap-2 shadow-xs cursor-pointer border border-surface-container-high"
            >
              <span className="material-symbols-outlined text-lg text-tertiary">chrome_reader_mode</span>
              <span>Try Web Reader</span>
            </button>
          </div>

          {/* Metrics Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-space-md pt-space-md">
            <div className="p-space-sm bg-surface-container-lowest rounded-lg shadow-sm border border-surface-container">
              <div className="font-headline-sm text-headline-sm font-bold text-primary">14,280+</div>
              <div className="font-label-sm text-label-sm text-on-surface-variant">Verified Works</div>
            </div>
            <div className="p-space-sm bg-surface-container-lowest rounded-lg shadow-sm border border-surface-container">
              <div className="font-headline-sm text-headline-sm font-bold text-tertiary">100% Free</div>
              <div className="font-label-sm text-label-sm text-on-surface-variant">Waqf Endowment</div>
            </div>
            <div className="p-space-sm bg-surface-container-lowest rounded-lg shadow-sm border border-surface-container">
              <div className="font-headline-sm text-headline-sm font-bold text-primary">48</div>
              <div className="font-label-sm text-label-sm text-on-surface-variant">Scholarly Languages</div>
            </div>
            <div className="p-space-sm bg-surface-container-lowest rounded-lg shadow-sm border border-surface-container">
              <div className="font-headline-sm text-headline-sm font-bold text-secondary">1.2M+</div>
              <div className="font-label-sm text-label-sm text-on-surface-variant">Global Accessions</div>
            </div>
          </div>
        </div>

        {/* Right Hero Column: 3D Showcase of Classic Volumes */}
        <div className="lg:col-span-5 relative flex items-center justify-center py-space-lg select-none">
          {/* Ambient Glow Behind Stack */}
          <div className="absolute w-72 h-72 rounded-full bg-tertiary-container/10 filter blur-3xl pointer-events-none"></div>
          
          <div className="relative w-full max-w-md h-[460px] flex items-center justify-center">
            {/* Book 1: Al-Bidayah wan-Nihayah (Background, offset left) */}
            <div
              onClick={() => onSelectBook(books.find(b => b.id === 'bidayah-wan-nihayah') || books[0])}
              className="absolute -left-2 top-8 w-56 h-80 rounded-xl bg-primary-container text-on-primary shadow-xl p-space-md flex flex-col justify-between transform -rotate-12 hover:-rotate-6 hover:scale-105 transition-all duration-300 cursor-pointer overflow-hidden border border-tertiary-container/30"
            >
              <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffe088_1px,transparent_1px)] [background-size:12px_12px]"></div>
              <div className="relative z-10 flex justify-between items-start">
                <span className="font-label-sm text-label-sm px-2 py-0.5 rounded bg-tertiary-container text-on-primary font-semibold">
                  Tārīkh
                </span>
                <span className="material-symbols-outlined text-tertiary-fixed text-lg">bookmark</span>
              </div>
              <div className="relative z-10 text-center space-y-1">
                <p className="font-arabic font-title-lg text-title-lg text-tertiary-fixed font-bold leading-tight text-xl">
                  البداية والنهاية
                </p>
                <p className="font-body-sm text-body-sm font-medium tracking-wide">Al-Bidāyah wan-Nihāyah</p>
                <p className="font-label-sm text-label-sm text-on-primary-container">Ibn Kathīr (d. 774 AH)</p>
              </div>
              <div className="relative z-10 pt-space-xs flex justify-between items-center text-[11px] text-tertiary-fixed-dim border-t border-primary/40">
                <span>Vol. 1 of 14</span>
                <span>840 pgs</span>
              </div>
            </div>

            {/* Book 2: Ihya Ulum al-Din (Middle, offset right) */}
            <div
              onClick={() => onSelectBook(books.find(b => b.id === 'ihya-ulum-al-din') || books[2])}
              className="absolute -right-2 top-14 w-60 h-84 rounded-xl bg-secondary text-on-secondary shadow-2xl p-space-md flex flex-col justify-between transform rotate-12 hover:rotate-6 hover:scale-105 transition-all duration-300 cursor-pointer overflow-hidden border border-white/20"
            >
              <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:10px_10px]"></div>
              <div className="relative z-10 flex justify-between items-start">
                <span className="font-label-sm text-label-sm px-2 py-0.5 rounded bg-surface-container-highest text-primary font-semibold">
                  Tazkiyah
                </span>
                <span className="material-symbols-outlined text-secondary-fixed text-lg">workspace_premium</span>
              </div>
              <div className="relative z-10 text-center space-y-1">
                <p className="font-arabic font-title-lg text-title-lg text-secondary-fixed font-bold leading-tight text-xl">
                  إحياء علوم الدين
                </p>
                <p className="font-body-sm text-body-sm font-medium tracking-wide">Iḥyā’ ‘Ulūm al-Dīn</p>
                <p className="font-label-sm text-label-sm text-secondary-fixed-dim">Imām al-Ghazālī (d. 505 AH)</p>
              </div>
              <div className="relative z-10 pt-space-xs flex justify-between items-center text-[11px] text-secondary-fixed-dim border-t border-secondary-fixed/20">
                <span>Critical Edition</span>
                <span>1,120 pgs</span>
              </div>
            </div>

            {/* Book 3: Riyad as-Salihin (Front & Center) */}
            <div
              onClick={() => onOpenReader(books.find(b => b.id === 'riyad-salihin'))}
              className="relative z-20 w-64 h-96 rounded-xl bg-surface-container-lowest text-on-surface shadow-2xl p-space-lg flex flex-col justify-between transform hover:-translate-y-2 hover:shadow-2xl transition-all duration-300 cursor-pointer border border-tertiary-container/40"
            >
              <div className="flex justify-between items-center">
                <span className="inline-flex items-center gap-1 font-label-sm text-label-sm px-2.5 py-0.5 rounded-full bg-primary-container text-on-primary font-semibold">
                  <span className="material-symbols-outlined text-xs">verified</span> Hadīth Core
                </span>
                <span className="font-label-sm text-label-sm text-tertiary font-bold">1445 AH Codex</span>
              </div>
              <div className="my-auto text-center space-y-2">
                <div className="w-12 h-12 mx-auto rounded-full bg-surface-container-high flex items-center justify-center text-tertiary mb-2 shadow-xs">
                  <span className="material-symbols-outlined text-2xl">menu_book</span>
                </div>
                <h2 className="font-arabic font-headline-sm text-headline-sm text-primary font-bold text-2xl">
                  رياض الصالحين
                </h2>
                <p className="font-title-md text-title-md font-semibold text-on-surface">Riyāḍ aṣ-Ṣāliḥīn</p>
                <p className="font-body-sm text-body-sm text-on-surface-variant">The Gardens of the Righteous</p>
                <div className="h-0.5 w-12 bg-tertiary-container mx-auto rounded"></div>
                <p className="font-label-sm text-label-sm text-tertiary font-medium">Imām Yaḥyā ibn Sharaf an-Nawawī</p>
              </div>
              <div className="bg-surface-container-low rounded-lg p-2.5 flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm border border-surface-container">
                <div className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm text-primary">menu_book</span>
                  <span>1,896 Hadīth</span>
                </div>
                <span className="font-semibold text-primary">Instant Reader →</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Category Showcase Grid */}
      <section className="py-space-xl">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-space-lg">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-tertiary-container"></span>
              <span className="font-label-sm text-label-sm uppercase tracking-wider text-tertiary font-semibold">
                Canonical Disciplines
              </span>
            </div>
            <h2 className="font-headline-md text-headline-md font-bold text-primary">Classified Sciences of Knowledge</h2>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-xl">
              Curated primary sources organized systematically across classical Islamic jurisprudence, exegesis, transmitted traditions, and theology.
            </p>
          </div>
          <button
            onClick={() => onNavigate('categories')}
            className="mt-4 md:mt-0 inline-flex items-center gap-1 font-title-md text-title-md text-primary font-semibold hover:text-tertiary transition-colors cursor-pointer"
          >
            <span>View Full 28 Classifications</span>
            <span className="material-symbols-outlined text-base">arrow_forward</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-space-lg">
          {categories.slice(0, 6).map((cat) => (
            <div
              key={cat.id}
              onClick={() => onNavigate('categories')}
              className="group relative bg-surface-container-lowest rounded-xl p-space-lg shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between border border-surface-container cursor-pointer"
            >
              <div className="space-y-space-md">
                <div className="flex items-center justify-between">
                  <span className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center text-primary group-hover:bg-primary-container group-hover:text-on-primary transition-colors">
                    <span className="material-symbols-outlined text-2xl">{cat.icon}</span>
                  </span>
                  <span className="font-arabic font-title-lg text-title-lg text-tertiary font-bold text-xl">
                    {cat.arabicName}
                  </span>
                </div>
                <div>
                  <h3 className="font-title-lg text-title-lg font-bold text-primary group-hover:text-tertiary transition-colors">
                    {cat.name}
                  </h3>
                  <p className="font-body-sm text-body-sm text-on-surface-variant mt-1 leading-relaxed">
                    {cat.description}
                  </p>
                </div>
                <div className="flex flex-wrap gap-1 font-label-sm text-label-sm text-on-surface-variant">
                  {cat.tags.map((tag, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded bg-surface-container text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              <div className="pt-space-md mt-space-md flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm border-t border-surface-container">
                <span className="font-semibold text-primary">{cat.volumeCount.toLocaleString()} Volumes</span>
                <span className="group-hover:translate-x-1 transition-transform text-tertiary font-semibold flex items-center gap-1">
                  Browse →
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured & Recommended Books Shelf */}
      <section className="py-space-xl" id="featured-shelf">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-md mb-space-lg">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-tertiary-container text-lg">star</span>
              <span className="font-label-sm text-label-sm uppercase tracking-wider text-tertiary font-semibold">
                Scholarly Selection
              </span>
            </div>
            <h2 className="font-headline-md text-headline-md font-bold text-primary">Featured &amp; Critical Editions</h2>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-surface-container-high rounded-lg overflow-x-auto border border-surface-container">
            {filterTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveFeaturedTab(tab)}
                className={`px-3 py-1.5 rounded-md font-title-md text-sm whitespace-nowrap transition-all cursor-pointer ${
                  activeFeaturedTab === tab
                    ? 'bg-surface-container-lowest text-on-surface font-semibold shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* 4 Rich Book Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-space-lg">
          {getFilteredBooks().map((book) => (
            <div
              key={book.id}
              className="group bg-surface-container-lowest rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between overflow-hidden border border-surface-container"
            >
              <div 
                className="relative h-56 bg-surface-container-high overflow-hidden cursor-pointer"
                onClick={() => onSelectBook(book)}
              >
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  src={book.coverImage}
                  alt={book.title}
                />
                <div className="absolute top-2 left-2 flex gap-1">
                  <span className={`px-2 py-0.5 rounded font-label-sm text-label-sm font-semibold shadow-sm ${book.badgeColor || 'bg-primary-container text-on-primary'}`}>
                    {book.badge || book.disciplineName}
                  </span>
                </div>
                <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-surface/90 backdrop-blur-sm text-on-surface font-label-sm text-label-sm font-medium shadow-xs">
                  {book.pages} pgs • {book.sizeMb} MB
                </div>
              </div>

              <div className="p-space-md flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-tertiary">
                    <span className="font-arabic font-title-md text-title-md font-bold text-lg">
                      {book.arabicTitle}
                    </span>
                    <span className="material-symbols-outlined text-sm" title="Academic Council Verified">
                      verified
                    </span>
                  </div>
                  <h3 
                    onClick={() => onSelectBook(book)}
                    className="font-title-md text-title-md font-bold text-primary group-hover:text-tertiary transition-colors line-clamp-1 cursor-pointer"
                  >
                    {book.title}
                  </h3>
                  <p className="font-body-sm text-body-sm text-on-surface-variant line-clamp-1">
                    {book.author}
                  </p>
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {book.formats.slice(0, 3).map((fmt, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-surface-container text-on-surface-variant font-label-sm text-xs font-medium">
                        {fmt}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-space-md mt-space-md grid grid-cols-2 gap-2 border-t border-surface-container">
                  <button
                    onClick={() => onOpenReader(book)}
                    className="py-2 px-3 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-title-md text-title-md text-center transition-colors flex items-center justify-center gap-1 cursor-pointer text-xs"
                  >
                    <span className="material-symbols-outlined text-base">chrome_reader_mode</span>
                    <span>Read</span>
                  </button>
                  <button
                    onClick={() => onOpenDownload(book)}
                    className="py-2 px-3 rounded-lg bg-primary-container hover:bg-primary text-on-primary font-title-md text-title-md text-center transition-colors flex items-center justify-center gap-1 shadow-sm cursor-pointer text-xs"
                  >
                    <span className="material-symbols-outlined text-base">download</span>
                    <span>Get</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* In-Browser Desktop Reading Experience Preview */}
      <section className="py-space-xl" id="reader-preview">
        <div className="space-y-2 mb-space-lg text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container text-tertiary font-label-sm text-label-sm font-semibold border border-surface-container">
            <span className="material-symbols-outlined text-sm">devices</span>
            <span>Zero Installation • Built-in Scholar Apparatus</span>
          </div>
          <h2 className="font-headline-md text-headline-md font-bold text-primary">
            Uncompromising Desktop Reading Interface
          </h2>
          <p className="font-body-md text-body-md text-on-surface-variant">
            Experience seamless parallel translation, instant morphological breakdown, footnote inspection, and synchronized vocalization in one distraction-free canvas.
          </p>
        </div>

        {/* Mockup Container */}
        <div className={`rounded-2xl shadow-xl overflow-hidden flex flex-col border border-surface-container transition-colors ${
          readerTheme === 'night' 
            ? 'bg-[#0d1a14] text-[#e5ede9]' 
            : readerTheme === 'sepia' 
              ? 'bg-[#fffcf7] text-[#26211a]' 
              : 'bg-surface-container-lowest text-on-surface'
        }`}>
          {/* Reader Toolbar */}
          <div className="bg-surface-container-low px-space-md py-space-sm flex flex-wrap items-center justify-between gap-2 border-b border-surface-container">
            <div className="flex items-center gap-space-md">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-error/70 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-tertiary/70 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-primary/70 inline-block"></span>
              </div>
              <span className="font-title-md text-title-md font-semibold text-primary truncate max-w-xs sm:max-w-md">
                {readingSection.bookTitle} — Book {readingSection.chapterNumber}: {readingSection.chapterTitleEn}
              </span>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-space-sm text-on-surface-variant">
              {/* Canvas Theme Selector */}
              <div className="hidden sm:flex items-center bg-surface-container rounded-lg p-0.5 gap-0.5 text-xs">
                <button
                  onClick={() => setReaderTheme('parchment')}
                  className={`px-2 py-1 rounded transition-colors ${
                    readerTheme === 'parchment' ? 'bg-surface-container-lowest text-on-surface font-semibold shadow-xs' : 'hover:text-on-surface'
                  }`}
                >
                  Parchment
                </button>
                <button
                  onClick={() => setReaderTheme('night')}
                  className={`px-2 py-1 rounded transition-colors ${
                    readerTheme === 'night' ? 'bg-[#192e25] text-white font-semibold shadow-xs' : 'hover:text-on-surface'
                  }`}
                >
                  Night
                </button>
                <button
                  onClick={() => setReaderTheme('sepia')}
                  className={`px-2 py-1 rounded transition-colors ${
                    readerTheme === 'sepia' ? 'bg-[#ded1c1] text-[#26211a] font-semibold shadow-xs' : 'hover:text-on-surface'
                  }`}
                >
                  Sepia
                </button>
              </div>

              {/* Font Sizer */}
              <div className="flex items-center bg-surface-container rounded-lg px-2 py-1 gap-1">
                <button
                  onClick={() => setReaderFontSize(Math.max(14, readerFontSize - 2))}
                  className="font-label-sm text-label-sm font-bold px-1 hover:text-primary cursor-pointer"
                  title="Smaller font"
                >
                  A-
                </button>
                <span className="text-xs text-outline">|</span>
                <button
                  onClick={() => setReaderFontSize(Math.min(26, readerFontSize + 2))}
                  className="font-label-sm text-label-sm font-bold px-1 hover:text-primary cursor-pointer"
                  title="Larger font"
                >
                  A+
                </button>
              </div>

              {/* Parallel Split Toggle */}
              <button
                onClick={() => setShowParallelTranslation(!showParallelTranslation)}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  showParallelTranslation ? 'bg-primary-container text-on-primary' : 'hover:bg-surface-container'
                }`}
                title="Toggle Parallel Translation"
              >
                <span className="material-symbols-outlined text-lg">vertical_split</span>
              </button>

              {/* Audio Playback button */}
              <button
                onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isPlayingAudio ? 'bg-tertiary-container text-on-primary animate-pulse' : 'hover:bg-surface-container'
                }`}
                title={isPlayingAudio ? "Pause Recitation" : "Listen to Recitation"}
              >
                <span className="material-symbols-outlined text-lg">
                  {isPlayingAudio ? 'pause' : 'volume_up'}
                </span>
              </button>

              {/* Full Reader Studio View */}
              <button
                onClick={() => onOpenReader()}
                className="p-1.5 rounded-lg hover:bg-surface-container cursor-pointer"
                title="Open in Dedicated Reader Studio"
              >
                <span className="material-symbols-outlined text-lg">fullscreen</span>
              </button>
            </div>
          </div>

          {/* Reader Body (Dual Pane Preview) */}
          <div className="grid grid-cols-12 min-h-[460px]">
            {/* Left Marginalia Sidebar */}
            <div className="hidden md:block md:col-span-3 bg-surface-container-low/40 p-space-md space-y-space-md border-r border-surface-container">
              <div className="space-y-1">
                <p className="font-label-sm text-label-sm uppercase tracking-wider font-semibold text-on-surface-variant">
                  Table of Contents
                </p>
                <p className="font-title-md text-title-md font-semibold text-primary">
                  Hadīth #{readingSection.entryNumber} of {readingSection.totalEntries.toLocaleString()}
                </p>
              </div>

              <div className="space-y-1 font-body-sm text-body-sm">
                <div className="p-2 rounded bg-surface-container-lowest text-primary font-semibold shadow-xs flex items-center justify-between border border-surface-container">
                  <span>1. How Revelation Began</span>
                  <span className="material-symbols-outlined text-xs">chevron_right</span>
                </div>
                <div className="p-2 rounded hover:bg-surface-container-high text-on-surface-variant transition-colors flex items-center justify-between cursor-pointer">
                  <span>2. The Book of Belief (Īmān)</span>
                </div>
                <div className="p-2 rounded hover:bg-surface-container-high text-on-surface-variant transition-colors flex items-center justify-between cursor-pointer">
                  <span>3. The Book of Knowledge (‘Ilm)</span>
                </div>
                <div className="p-2 rounded hover:bg-surface-container-high text-on-surface-variant transition-colors flex items-center justify-between cursor-pointer">
                  <span>4. The Book of Ablution (Wuḍū’)</span>
                </div>
              </div>

              {/* Chain of Transmission Snapshot */}
              <div className="pt-space-md space-y-2 border-t border-surface-container">
                <div className="flex items-center justify-between">
                  <p className="font-label-sm text-label-sm uppercase tracking-wider font-semibold text-tertiary">
                    Isnād Chain Node
                  </p>
                  <span className="text-[10px] text-on-surface-variant">Click to inspect</span>
                </div>
                <div className="space-y-1.5 text-xs text-on-surface-variant">
                  {readingSection.isnadChain.slice(0, 4).map((node, i) => (
                    <div key={node.id}>
                      <button
                        onClick={() => onOpenNarrator(node)}
                        className="flex items-center gap-2 text-left hover:text-primary transition-colors cursor-pointer group"
                      >
                        <span className={`w-2 h-2 rounded-full group-hover:scale-125 transition-transform ${
                          i === 0 ? 'bg-tertiary-container' : 'bg-primary-container'
                        }`}></span>
                        <span className="group-hover:underline truncate max-w-[170px]">{node.name}</span>
                      </button>
                      {i < 3 && <div className="ml-1 w-0.5 h-2 bg-outline-variant"></div>}
                    </div>
                  ))}
                  <div className="ml-1 w-0.5 h-2 bg-outline-variant"></div>
                  <button
                    onClick={() => onOpenNarrator(readingSection.isnadChain[readingSection.isnadChain.length - 1])}
                    className="flex items-center gap-2 font-semibold text-primary hover:text-tertiary transition-colors cursor-pointer text-left"
                  >
                    <span className="w-2 h-2 rounded-full bg-primary"></span>
                    <span>{readingSection.isnadChain[readingSection.isnadChain.length - 1].name}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Center Reading Canvas */}
            <div className="col-span-12 md:col-span-9 p-space-lg flex flex-col justify-between">
              {isPlayingAudio && (
                <div className="mb-4 p-2.5 rounded-xl bg-tertiary-container/15 border border-tertiary-container/40 flex items-center justify-between text-xs text-tertiary">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-base animate-spin">graphic_eq</span>
                    <span>Playing authentic vocal recitation: <strong>Sheikh Mishary Rashid Alafasy</strong> (Kitāb Bad’ al-Waḥy)</span>
                  </div>
                  <span className="font-mono">00:42 / 01:15</span>
                </div>
              )}

              <div className={`grid gap-space-xl ${showParallelTranslation ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
                {/* Left Pane: English Vernacular & Scholarly Annotations */}
                {showParallelTranslation && (
                  <div className="space-y-space-md">
                    <div className="inline-flex items-center gap-1.5 font-label-sm text-label-sm text-on-surface-variant flex-wrap">
                      <span className="px-2 py-0.5 rounded bg-surface-container text-primary font-semibold">
                        {readingSection.englishHeading}
                      </span>
                      <span>• {readingSection.authenticityStatus}</span>
                    </div>

                    <div 
                      className="space-y-3 font-body-lg leading-relaxed"
                      style={{ fontSize: `${readerFontSize}px` }}
                    >
                      <p>
                        {readingSection.englishLeadText}{' '}
                        <span className="font-semibold text-primary underline decoration-tertiary/40">
                          {readingSection.englishHighlightText}
                        </span>
                      </p>
                      <p className="font-body-md text-on-surface-variant">
                        {readingSection.englishSubsequentText}
                      </p>
                    </div>

                    {/* Collapsible Scholarly Marginalia */}
                    <div className="bg-surface-container-low p-space-md rounded-xl space-y-1 border border-surface-container">
                      <div 
                        onClick={() => setActiveFootnoteOpen(!activeFootnoteOpen)}
                        className="flex items-center justify-between text-tertiary font-title-md text-title-md font-semibold cursor-pointer select-none"
                      >
                        <span className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-base">notes</span>
                          <span>{readingSection.footnotes[0].code} — {readingSection.footnotes[0].title}</span>
                        </span>
                        <span className="font-label-sm text-label-sm text-on-surface-variant flex items-center gap-1">
                          <span>{readingSection.footnotes[0].scholar} ({readingSection.footnotes[0].scholarDeathAH})</span>
                          <span className="material-symbols-outlined text-xs">
                            {activeFootnoteOpen ? 'expand_less' : 'expand_more'}
                          </span>
                        </span>
                      </div>
                      {activeFootnoteOpen && (
                        <p className="font-body-sm text-body-sm text-on-surface-variant pt-1 leading-relaxed">
                          {readingSection.footnotes[0].text}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {/* Right Pane: Classical Arabic (RTL, authentic spacing) */}
                <div className="space-y-space-md text-right flex flex-col justify-between" dir="rtl">
                  <div className="inline-flex items-center gap-2 self-start font-label-sm text-label-sm text-tertiary">
                    <span className="font-bold">حَدِيثٌ صَحِيحٌ</span>
                    <span className="text-outline-variant">•</span>
                    <span>رَقْمُ الحَدِيثِ : ١</span>
                  </div>

                  <div className="space-y-4">
                    <p 
                      className="font-arabic text-primary leading-loose font-medium"
                      style={{ fontSize: `${Math.round(readerFontSize * 1.35)}px` }}
                    >
                      {readingSection.arabicLead}
                    </p>

                    <div className="p-space-md rounded-xl bg-tertiary-fixed/20 text-on-tertiary-fixed text-right border border-tertiary-container/30">
                      <p 
                        className="font-arabic font-bold text-primary leading-relaxed"
                        style={{ fontSize: `${Math.round(readerFontSize * 1.45)}px` }}
                      >
                        {readingSection.arabicMatn}
                      </p>
                    </div>

                    {/* Interactive Word Inspector strip */}
                    <div className="p-2.5 rounded-lg bg-surface-container-low text-xs text-on-surface-variant space-y-1 border border-surface-container" dir="ltr">
                      <div className="flex items-center justify-between text-tertiary font-semibold">
                        <span className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-sm">spellcheck</span>
                          Click any key word for Root &amp; Grammar breakdown:
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {readingSection.wordAnalyses.map((w, idx) => (
                          <button
                            key={idx}
                            onClick={() => onOpenWordAnalysis(w)}
                            className="px-2 py-1 rounded bg-surface-container hover:bg-primary-container hover:text-on-primary text-primary font-arabic text-sm transition-colors cursor-pointer border border-surface-container-high"
                          >
                            {w.arabic}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm" dir="ltr">
                    <button
                      onClick={handleShareHadith}
                      className="inline-flex items-center gap-1 text-primary hover:text-tertiary font-semibold cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-sm">share</span>
                      <span>{shareToast ? 'Hadith link copied!' : 'Share Hadith'}</span>
                    </button>
                    <span className="text-outline-variant">{readingSection.arabicSubtext}</span>
                  </div>
                </div>
              </div>

              {/* Bottom Reader Nav Ribbon */}
              <div className="mt-space-lg pt-space-sm flex items-center justify-between text-on-surface-variant font-body-sm text-body-sm border-t border-surface-container">
                <button 
                  onClick={() => onOpenReader()}
                  className="inline-flex items-center gap-1 hover:text-primary font-semibold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-sm">arrow_back</span> Previous Section
                </button>
                <span className="font-label-sm text-label-sm">
                  Page {readingSection.currentPage} of {readingSection.totalPages} • Kitāb Bad’ al-Waḥy
                </span>
                <button 
                  onClick={() => onOpenReader()}
                  className="inline-flex items-center gap-1 hover:text-primary font-semibold cursor-pointer"
                >
                  Next Section <span className="material-symbols-outlined text-sm">arrow_forward</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Al-Maktabah & Scholarly Mission (2-Column Minimalist Layout) */}
      <section className="py-space-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-xl items-center">
          {/* Left Column: Commitment to Waqf */}
          <div className="lg:col-span-6 space-y-space-md">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container text-primary font-label-sm text-label-sm font-semibold border border-surface-container">
              <span className="material-symbols-outlined text-sm text-tertiary-container">history</span>
              <span>Endowment for Eternity</span>
            </div>
            <h2 className="font-headline-md text-headline-md font-bold text-primary">
              Our Commitment to Waqf &amp; Classical Preservation
            </h2>
            <p className="font-body-lg text-body-lg text-on-surface-variant leading-relaxed">
              Knowledge in Islam is a communal obligation (<em>Farḍ Kifāyah</em>) and a timeless charity (<em>Ṣadaqah Jāriyah</em>). Al-Maktabah operates as an independent academic digital waqf:
            </p>
            <div className="space-y-space-sm font-body-md text-body-md text-on-surface-variant">
              <div className="flex items-start gap-space-sm">
                <span className="material-symbols-outlined text-primary text-xl shrink-0 mt-0.5">check_circle</span>
                <p>
                  <strong className="text-primary">No Paywalls, Ever:</strong> Every manuscript, critical edition, and translation is 100% open-access without subscription barriers or commercial advertisements.
                </p>
              </div>
              <div className="flex items-start gap-space-sm">
                <span className="material-symbols-outlined text-primary text-xl shrink-0 mt-0.5">check_circle</span>
                <p>
                  <strong className="text-primary">4K Ultra-High Density Digitization:</strong> Preserving fragile papyri, parchment codices, and rare Ottoman/Abbasid bindings before physical decay destroys them.
                </p>
              </div>
              <div className="flex items-start gap-space-sm">
                <span className="material-symbols-outlined text-primary text-xl shrink-0 mt-0.5">check_circle</span>
                <p>
                  <strong className="text-primary">Rigorously Authenticated by Council:</strong> Every text is cross-referenced with extant historical copies by seasoned specialists in traditional Islamic philology.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Feature Matrix */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm space-y-2 border border-surface-container">
              <div className="w-10 h-10 rounded-lg bg-surface-container flex items-center justify-center text-primary">
                <span className="material-symbols-outlined text-xl">copyright</span>
              </div>
              <h3 className="font-title-md text-title-md font-bold text-primary">Open Academic Licensing</h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Licensed under CC-BY-NC for research centers, university faculties, and educational initiatives globally.
              </p>
            </div>

            <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm space-y-2 border border-surface-container">
              <div className="w-10 h-10 rounded-lg bg-surface-container flex items-center justify-center text-tertiary">
                <span className="material-symbols-outlined text-xl">spellcheck</span>
              </div>
              <h3 className="font-title-md text-title-md font-bold text-primary">Morphological Search</h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Search with full Arabic diacritics (<em>tashkīl</em>) or stripped bare roots with stem lemmatization support.
              </p>
            </div>

            <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm space-y-2 border border-surface-container">
              <div className="w-10 h-10 rounded-lg bg-surface-container flex items-center justify-center text-primary">
                <span className="material-symbols-outlined text-xl">sync_alt</span>
              </div>
              <h3 className="font-title-md text-title-md font-bold text-primary">Cross-Referencing</h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Instant live bidirectional links connecting Hadith citations directly into corresponding Qur’anic verses.
              </p>
            </div>

            <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm space-y-2 border border-surface-container">
              <div className="w-10 h-10 rounded-lg bg-surface-container flex items-center justify-center text-secondary">
                <span className="material-symbols-outlined text-xl">offline_pin</span>
              </div>
              <h3 className="font-title-md text-title-md font-bold text-primary">Offline Bundles</h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Download entire library sections as compressed standalone packages for rural madrasas with no internet.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Scholarly Newsletter & Digest Strip */}
      <section className="py-space-xl">
        <div className="bg-primary-container text-on-primary rounded-2xl p-space-xl shadow-lg relative overflow-hidden">
          {/* Decorative Arabesque Vector Overlay */}
          <div className="absolute -right-12 -top-12 w-64 h-64 opacity-5 pointer-events-none">
            <svg fill="currentColor" viewBox="0 0 100 100">
              <polygon points="50,0 62,38 100,38 69,62 81,100 50,75 19,100 31,62 0,38 38,38"></polygon>
            </svg>
          </div>
          <div className="relative z-10 max-w-3xl mx-auto text-center space-y-space-md">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-tertiary-container text-on-primary font-label-sm text-label-sm uppercase font-semibold">
              <span className="material-symbols-outlined text-sm">mark_email_read</span>
              The Monthly Scholarly Dispatch
            </span>
            <h2 className="font-display font-headline-md text-headline-md font-bold text-2xl sm:text-3xl text-on-primary">
              Join 140,000+ Seekers &amp; Researchers of Sacred Knowledge
            </h2>
            <p className="font-body-md text-body-md text-on-primary-container max-w-xl mx-auto">
              Receive monthly digests of newly digitized manuscripts, authenticated translations, paleographic findings, and academic reading roadmaps. No promotional spam.
            </p>

            {dispatchSubscribed ? (
              <div className="p-4 bg-tertiary-container/30 border border-tertiary-container rounded-xl text-on-primary font-semibold flex items-center justify-center gap-2">
                <span className="material-symbols-outlined text-xl">check_circle</span>
                <span>Alhamdulillah! You have been enrolled in the Monthly Scholarly Dispatch.</span>
              </div>
            ) : (
              <form onSubmit={handleDispatchSubmit} className="flex flex-col sm:flex-row items-center justify-center gap-space-sm pt-space-xs max-w-md mx-auto">
                <input
                  className="w-full sm:w-auto flex-1 px-4 py-3 rounded-lg bg-surface-container-lowest text-on-surface placeholder:text-outline font-body-sm text-body-sm focus:outline-none shadow-sm"
                  placeholder="scholar@university.edu"
                  type="email"
                  value={dispatchEmail}
                  onChange={(e) => setDispatchEmail(e.target.value)}
                  required
                />
                <button
                  className="w-full sm:w-auto px-6 py-3 rounded-lg bg-tertiary-container text-on-primary font-title-md text-title-md hover:bg-tertiary transition-colors flex items-center justify-center gap-2 shadow-sm font-semibold shrink-0 cursor-pointer"
                  type="submit"
                >
                  <span>Subscribe</span>
                  <span className="material-symbols-outlined text-base">arrow_forward</span>
                </button>
              </form>
            )}

            <div className="flex items-center justify-center gap-space-lg text-on-primary-container font-label-sm text-label-sm pt-space-xs text-xs">
              <span className="flex items-center gap-1">
                <span className="material-symbols-outlined text-xs">lock</span> 100% Privacy Protected
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <span className="material-symbols-outlined text-xs">history_edu</span> Academic Editorial Board
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
