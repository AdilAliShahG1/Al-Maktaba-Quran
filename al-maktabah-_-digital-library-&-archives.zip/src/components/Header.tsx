import React, { useState } from 'react';
import { ReaderTheme } from '../types/library';

interface HeaderProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onOpenSearch: () => void;
  currentTheme: ReaderTheme;
  onThemeChange: (theme: ReaderTheme) => void;
  currentLang: 'EN' | 'AR';
  onLangChange: (lang: 'EN' | 'AR') => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPath,
  onNavigate,
  onOpenSearch,
  currentTheme,
  onThemeChange,
  currentLang,
  onLangChange,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'browse-library', label: 'Browse Library' },
    { id: 'categories', label: 'Categories' },
    { id: 'manuscripts', label: 'Manuscripts' },
    { id: 'reader-studio', label: 'Reader Studio' },
    { id: 'latest-releases', label: 'Latest Releases' },
    { id: 'about', label: 'About' },
  ];

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-surface/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-surface-container">
      {/* Top Banner: Daily Insight Calligraphy & Hijri Date */}
      <div className="w-full bg-primary-container text-on-primary py-space-xs px-4 sm:px-8 lg:px-margin">
        <div className="max-w-7xl mx-auto flex items-center justify-between font-body-sm text-body-sm">
          <div className="flex items-center gap-space-md truncate">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-tertiary-container text-on-primary font-label-sm text-label-sm font-semibold tracking-wide uppercase shrink-0">
              Daily Insight
            </span>
            <span className="font-arabic text-tertiary-fixed font-medium truncate text-base">
              « اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ »
            </span>
            <span className="hidden lg:inline text-on-primary-container text-opacity-90 italic font-body-sm text-body-sm truncate">
              “Read in the name of your Lord who created.” (Surah Al-’Alaq 96:1)
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-space-lg text-on-primary-container font-label-sm text-label-sm shrink-0">
            <span className="flex items-center gap-1">
              <span className="material-symbols-outlined text-sm text-tertiary-fixed-dim">calendar_month</span>
              14 Shawwal 1445 AH
            </span>
            <span className="text-outline-variant">•</span>
            <span className="flex items-center gap-1">
              <span className="material-symbols-outlined text-sm text-tertiary-fixed-dim">auto_stories</span>
              54,280 Manuscripts Catalogued
            </span>
          </div>
        </div>
      </div>

      {/* Main App Navigation Bar */}
      <div className="h-20 w-full max-w-7xl mx-auto px-4 sm:px-8 lg:px-margin flex items-center justify-between gap-space-md">
        {/* Brand Logo & Name */}
        <div 
          onClick={() => onNavigate('home')} 
          className="flex items-center gap-space-md shrink-0 cursor-pointer select-none"
        >
          <img 
            alt="Al-Maktabah Brand Logo" 
            className="h-8 w-auto object-contain" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBkk5vdhfETWDMXgUobuz8b7OFIRxT1RnZyf7NS9WywvGhN2DjXfBC38oWKpOPBa1Qs_m1ca4JDUU4MPkxVPn_Sc46Y9KuVauZl1My3j3Je5ikE7fJ0utasVbauXGLar-TbkdJmDkpxhfmPHXPvXvl3Bffa8uNNmdDFvmiUQbiT0GyDAuAJEGh7OHztOzMPqH7Ugw6p3FwSAO-cR9R2gvZLOgmsldiGILWTav5h_tWWlYQ6vJe9X8xI" 
          />
          <div className="flex flex-col">
            <div className="flex items-baseline gap-2">
              <span className="font-display font-headline-sm text-headline-sm text-primary tracking-tight font-semibold">
                Al-Maktabah
              </span>
              <span className="font-arabic font-title-lg text-title-lg text-tertiary font-bold">
                المكتبة
              </span>
            </div>
            <span className="font-label-sm text-label-sm text-on-surface-variant tracking-wider uppercase">
              Knowledge Hub &amp; Digital Archives
            </span>
          </div>
        </div>

        {/* Center Nav Links (Desktop) */}
        <nav className="hidden xl:flex items-center gap-1">
          {navLinks.map((link) => {
            const isActive = currentPath === link.id;
            return (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`px-3 py-2 rounded-lg font-title-md text-sm transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-primary-container text-on-primary font-semibold shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Right Action Tools: Search, Theme, Language, Profile */}
        <div className="flex items-center gap-2 sm:gap-space-md shrink-0">
          {/* Quick Search Pill */}
          <div 
            onClick={onOpenSearch}
            className="relative hidden md:flex items-center bg-surface-container-lowest rounded-lg px-3 py-1.5 shadow-[0_1px_4px_rgba(0,0,0,0.03)] border border-surface-container-high cursor-pointer hover:border-tertiary-container transition-colors w-52 lg:w-64"
          >
            <span className="material-symbols-outlined text-tertiary-container mr-2 text-lg">search</span>
            <span className="w-full font-body-sm text-body-sm text-outline truncate select-none">
              Search treatises, isnāds...
            </span>
            <kbd className="hidden lg:inline-flex items-center px-1.5 py-0.5 text-[10px] font-label-sm text-on-surface-variant bg-surface-container rounded ml-1">
              ⌘K
            </kbd>
          </div>

          {/* Mobile Search Icon */}
          <button 
            onClick={onOpenSearch}
            className="md:hidden p-2 rounded-lg text-on-surface-variant hover:bg-surface-container"
            title="Search"
          >
            <span className="material-symbols-outlined text-xl">search</span>
          </button>

          {/* Theme Switcher Trio: Light, Sepia, Night */}
          <div className="flex items-center bg-surface-container-low rounded-lg p-0.5 gap-0.5 border border-surface-container">
            <button
              onClick={() => onThemeChange('parchment')}
              className={`px-2 py-1 rounded text-label-sm font-label-sm flex items-center gap-1 transition-all ${
                currentTheme === 'parchment'
                  ? 'bg-surface-container-lowest text-on-surface font-semibold shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
              title="Light Parchment"
            >
              <span className="material-symbols-outlined text-sm text-tertiary-container">light_mode</span>
              <span className="hidden 2xl:inline">Light</span>
            </button>
            <button
              onClick={() => onThemeChange('sepia')}
              className={`px-2 py-1 rounded text-label-sm font-label-sm flex items-center gap-1 transition-all ${
                currentTheme === 'sepia'
                  ? 'bg-surface-container-lowest text-on-surface font-semibold shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
              title="Warm Sepia Parchment"
            >
              <span className="material-symbols-outlined text-sm text-tertiary">auto_stories</span>
              <span className="hidden 2xl:inline">Sepia</span>
            </button>
            <button
              onClick={() => onThemeChange('night')}
              className={`px-2 py-1 rounded text-label-sm font-label-sm flex items-center gap-1 transition-all ${
                currentTheme === 'night'
                  ? 'bg-surface-container-lowest text-on-surface font-semibold shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
              title="Night Emerald"
            >
              <span className="material-symbols-outlined text-sm text-primary-container">dark_mode</span>
              <span className="hidden 2xl:inline">Night</span>
            </button>
          </div>

          {/* Language Switcher */}
          <div className="hidden sm:flex items-center bg-surface-container-high rounded-lg p-0.5 border border-surface-container">
            <button
              onClick={() => onLangChange('EN')}
              className={`px-2 py-1 rounded font-label-sm text-label-sm font-semibold transition-colors ${
                currentLang === 'EN'
                  ? 'bg-surface-container-lowest text-on-surface shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => onLangChange('AR')}
              className={`px-2 py-1 rounded font-label-sm text-label-sm font-semibold transition-colors ${
                currentLang === 'AR'
                  ? 'bg-surface-container-lowest text-on-surface shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              عربي
            </button>
          </div>

          {/* User Profile Avatar */}
          <div className="flex items-center pl-space-xs">
            <img 
              alt="Scholar Profile" 
              className="w-8 h-8 rounded-full object-cover ring-2 ring-tertiary-container ring-offset-2 ring-offset-surface cursor-pointer" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCp6hjwy-OtUiOFhXULVfc39TXd10KeuRXfFUG5sIqXVsYPcK5Q3_sXBUEWdWMQiSBlB-RSNxE5NSOG1gAp2qrAfJdN9ukCek7BibNabA20PebeMtnMMzmI8puJlGt9eWVf06upC4lVHJo3seg2JriFqz6XknjL28boYGcDkKgVHJ7UJLGLIr5O_cfctFnbYX28zDj5WwUvVllMUdmi0tkU4ok2-XSiS14eZeUo7chnLI3iQWQdDkYf" 
            />
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-lg text-on-surface hover:bg-surface-container"
            aria-label="Toggle navigation"
          >
            <span className="material-symbols-outlined text-2xl">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-surface-container-low border-b border-surface-container p-4 space-y-2 animate-fade-in shadow-lg">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-surface-container">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setMobileMenuOpen(false);
                }}
                className={`p-2.5 rounded-lg text-left text-sm font-semibold flex items-center justify-between ${
                  currentPath === link.id
                    ? 'bg-primary-container text-on-primary'
                    : 'text-on-surface-variant hover:bg-surface-container'
                }`}
              >
                <span>{link.label}</span>
                <span className="material-symbols-outlined text-xs">arrow_forward</span>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-2 text-xs text-on-surface-variant">
            <span>Hijri 1445 AH Edition</span>
            <div className="flex gap-2">
              <button 
                onClick={() => onLangChange('EN')}
                className={`px-2 py-1 rounded font-semibold ${currentLang === 'EN' ? 'bg-primary text-white' : ''}`}
              >
                English
              </button>
              <button 
                onClick={() => onLangChange('AR')}
                className={`px-2 py-1 rounded font-semibold ${currentLang === 'AR' ? 'bg-primary text-white' : ''}`}
              >
                العربية
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
