import React, { useState, useEffect } from 'react';
import { Book, IsnadNode, ReaderTheme, WordAnalysis } from './types/library';
import { BOOKS, CATEGORIES, MANUSCRIPTS, PRIMARY_READING_SECTION } from './data/mockLibrary';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CommandPalette } from './components/CommandPalette';
import { BookDetailModal } from './components/BookDetailModal';
import { DownloadModal } from './components/DownloadModal';
import { NarratorBiographyModal } from './components/NarratorBiographyModal';
import { MorphologyModal } from './components/MorphologyModal';
import { HomeView } from './views/HomeView';
import { BrowseLibraryView } from './views/BrowseLibraryView';
import { CategoriesView } from './views/CategoriesView';
import { ReaderStudioView } from './views/ReaderStudioView';
import { ManuscriptsView } from './views/ManuscriptsView';
import { LatestReleasesView } from './views/LatestReleasesView';
import { AboutView } from './views/AboutView';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>('home');
  const [currentTheme, setCurrentTheme] = useState<ReaderTheme>('parchment');
  const [currentLang, setCurrentLang] = useState<'EN' | 'AR'>('EN');

  // Modals state
  const [commandPaletteOpen, setCommandPaletteOpen] = useState<boolean>(false);
  const [selectedBookForModal, setSelectedBookForModal] = useState<Book | null>(null);
  const [downloadBook, setDownloadBook] = useState<Book | null>(null);
  const [selectedNarrator, setSelectedNarrator] = useState<IsnadNode | null>(null);
  const [selectedWord, setSelectedWord] = useState<WordAnalysis | null>(null);

  // Active book for reader studio
  const [readerBook, setReaderBook] = useState<Book>(BOOKS[1]); // Mukhtasar Bukhari
  const [searchFilterQuery, setSearchFilterQuery] = useState<string>('');

  // Apply theme to document body
  useEffect(() => {
    document.body.classList.remove('theme-sepia', 'theme-night');
    if (currentTheme === 'sepia') {
      document.body.classList.add('theme-sepia');
    } else if (currentTheme === 'night') {
      document.body.classList.add('theme-night');
    }
  }, [currentTheme]);

  // Scroll to top on navigation change
  const navigateTo = (path: string) => {
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenReader = (book?: Book) => {
    if (book) {
      setReaderBook(book);
    }
    navigateTo('reader-studio');
  };

  const handleSearchQueryFromHome = (query: string) => {
    setSearchFilterQuery(query);
    navigateTo('browse-library');
  };

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${
      currentTheme === 'night' 
        ? 'bg-[#0a1410] text-[#e5ede9]' 
        : currentTheme === 'sepia' 
          ? 'bg-[#f5ede1] text-[#26211a]' 
          : 'bg-[#fbf9f5] text-[#1b1c1a]'
    }`}>
      {/* Fixed Sticky Header */}
      <Header
        currentPath={currentPath}
        onNavigate={navigateTo}
        onOpenSearch={() => setCommandPaletteOpen(true)}
        currentTheme={currentTheme}
        onThemeChange={setCurrentTheme}
        currentLang={currentLang}
        onLangChange={setCurrentLang}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 w-full pt-28 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-margin">
          {currentPath === 'home' && (
            <HomeView
              books={BOOKS}
              categories={CATEGORIES}
              readingSection={PRIMARY_READING_SECTION}
              onSelectBook={(book) => setSelectedBookForModal(book)}
              onOpenReader={handleOpenReader}
              onOpenDownload={(book) => setDownloadBook(book)}
              onOpenNarrator={(narrator) => setSelectedNarrator(narrator)}
              onOpenWordAnalysis={(word) => setSelectedWord(word)}
              onNavigate={navigateTo}
              onSearchQuery={handleSearchQueryFromHome}
            />
          )}

          {currentPath === 'browse-library' && (
            <BrowseLibraryView
              books={BOOKS}
              onSelectBook={(book) => setSelectedBookForModal(book)}
              onOpenReader={handleOpenReader}
              onOpenDownload={(book) => setDownloadBook(book)}
              initialQuery={searchFilterQuery}
            />
          )}

          {currentPath === 'categories' && (
            <CategoriesView
              categories={CATEGORIES}
              onSelectCategory={(catId) => {
                setSearchFilterQuery(catId);
                navigateTo('browse-library');
              }}
              onNavigate={navigateTo}
            />
          )}

          {currentPath === 'reader-studio' && (
            <ReaderStudioView
              initialBook={readerBook}
              allBooks={BOOKS}
              readingSection={PRIMARY_READING_SECTION}
              onOpenNarrator={(narrator) => setSelectedNarrator(narrator)}
              onOpenWordAnalysis={(word) => setSelectedWord(word)}
              onNavigateHome={() => navigateTo('home')}
            />
          )}

          {currentPath === 'manuscripts' && (
            <ManuscriptsView manuscripts={MANUSCRIPTS} />
          )}

          {currentPath === 'latest-releases' && (
            <LatestReleasesView
              books={BOOKS}
              onSelectBook={(book) => setSelectedBookForModal(book)}
              onOpenReader={handleOpenReader}
              onOpenDownload={(book) => setDownloadBook(book)}
            />
          )}

          {currentPath === 'about' && <AboutView />}
        </div>
      </main>

      {/* Footer */}
      <Footer onNavigate={navigateTo} />

      {/* Modals & Dialogs */}
      <CommandPalette
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        books={BOOKS}
        categories={CATEGORIES}
        onSelectBook={(book) => setSelectedBookForModal(book)}
        onNavigate={navigateTo}
      />

      <BookDetailModal
        book={selectedBookForModal}
        onClose={() => setSelectedBookForModal(null)}
        onOpenReader={handleOpenReader}
        onDownload={(book) => {
          setSelectedBookForModal(null);
          setDownloadBook(book);
        }}
      />

      <DownloadModal
        book={downloadBook}
        onClose={() => setDownloadBook(null)}
      />

      <NarratorBiographyModal
        narrator={selectedNarrator}
        onClose={() => setSelectedNarrator(null)}
      />

      <MorphologyModal
        word={selectedWord}
        onClose={() => setSelectedWord(null)}
      />
    </div>
  );
}
